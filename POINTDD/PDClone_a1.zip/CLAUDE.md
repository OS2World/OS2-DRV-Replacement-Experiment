# CLAUDE.md — POINTDD.SYS open-source clone

Open-source replacement for OS/2's Pointer Device Driver (POINTDD.SYS), targeting Warp
4.52 and ArcaOS 5, first proven against the VirtualBox ArcaOS dev VM. **No IBM source for
this driver exists anywhere** (confirmed across three independent DDK archives — see
`PLAN.md` §1) — this is a from-scratch reimplementation against the documented protocol,
not a port. **Read `PLAN.md` before writing any code** — it has the full protocol
findings with citations, the scope decision, the toolchain recommendation, and — most
importantly — **§4, the blast-radius/safety section**: this driver loads unconditionally
at boot before the GUI exists, so a bug here can mean the VM doesn't boot at all, unlike
an additive driver. Follow its CONFIG.SYS-safety steps before the first load test.

---

## Reference (router first)

- OS/2 API / reference questions → `C:\Users\MI\Documents\Default Project\claude-os2-toolkit\os2ref\README.md`,
  then load only the doc(s) it routes to. For this project specifically: `drivers.md`
  (PDD ABI) + `kernel-services.md` (DevHelp) + `vio-kbd-mou.md` (MOU_* IOCtls).
- Toolkit headers (ground truth): `C:\Users\MI\Documents\Default Project\os2tk45\h`
  (`bsedev.h` has the full `MOU_*`/`PTR_*`/`SCR_*`/`VID_*` IOCtl tables this driver must
  speak — cite `bsedev.h:<line>` for any IOCtl constant).
- **Protocol-specific sources not in the toolkit** (this project surfaced these; not yet
  contributed back — see toolkit `CONTRIBUTING.md` if that's wanted later):
  - `C:\Temporal\1.- OS2\Projects\References\os2ddk2004\Docs-PDF\DISPLAY.pdf` — the
    official chapter on the Category 3/Function 73h Call Vector Table handshake between
    a pointer driver and a display driver. Extract text with
    `pdftotext -layout DISPLAY.pdf out.txt` (`pdftotext` is on PATH under `/mingw64/bin`
    in the Bash tool). See `PLAN.md` §2c for the exact line ranges already found.
  - `pointer.asm` (display-driver side of the draw-pointer contract, real IBM source) —
    e.g. `os2ddk2004\ZIP\VIDEO\DDK\video\src\video\vga32\svga256\pointer.asm`. Read this
    as the reference client for what our driver calls into on the video driver side —
    never disassemble POINTDD.SYS itself to fill gaps; there is no POINTDD.SYS binary
    reverse-engineering in this project, only reading of documented/public material.
  - Sibling project `WiFi-RTL8188EU-ArcaOS\` (in the Claude workspace, not this repo) —
    the proven 16-bit DDK build loop (`build.cmd`/`makefile`/`rtl_hdr.asm` pattern) and
    the COM1-serial-trace debugging technique this project reuses.

---

## Toolchain

**Recommended (see PLAN.md §3 for why, and to confirm/override): the 16-bit DDK
toolchain — MS C 6.0 + MASM + LINK**, the same one proven for the WiFi RTL8188EU driver.
POINTDD's documented contract is classic 16:16-segmented, dual-ring-callable OS/2 driver
convention, not flat 32-bit — this toolchain targets that directly. If OpenWatcom/32-bit
is preferred instead, say so before Phase 1's skeleton is written — it changes the driver
header/entry structure.

Build/test loop (same discipline as the WiFi project): edit on Windows, build on the
ArcaOS VM over the shared folder, reboot, read the COM1 serial trace. **Difference from
that project: back up CONFIG.SYS and confirm the Alt-F1/maintenance-partition recovery
path before every new boot-time behavior change** — see PLAN.md §4.

---

## Key conventions from the protocol research

- Device name: **`POINTER$`** (the default; a video handler can declare its own via
  `PtrDevP=`/`PtrDevR=` in its `VIDEO_DEVICES` entry — see PLAN.md §2c).
- `IOCTL_POINTINGDEVICE` = `0x07` (the `MOU_*` ring-3 surface toward MOUSE.SYS/PM).
- `IOCTL_SCR_AND_PTRDRAW` = `0x03`, init `Function 73h` (the display-driver handshake).
- Pointer model: 32×32, AND/XOR masks, hot-spot coordinate; display driver owns pointer
  exclusion during its own drawing (PLAN.md §2d).
